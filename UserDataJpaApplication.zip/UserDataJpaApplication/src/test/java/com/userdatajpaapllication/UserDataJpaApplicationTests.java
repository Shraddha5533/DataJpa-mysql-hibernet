package com.userdatajpaapllication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserDataJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
